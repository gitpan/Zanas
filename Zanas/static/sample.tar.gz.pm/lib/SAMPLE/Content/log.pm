################################################################################

sub select_log {

	my $start = $_REQUEST {start} + 0;

	my ($log, $cnt) = sql_select_all_cnt (<<EOS);
		SELECT 
			DATE_FORMAT(log.dt, '%d.%m.%Y %H:%i:%s') AS dt
			, log.type
			, log.action
			, log.error
			, users.label
		FROM 		
			log 
			INNER JOIN users ON log.id_user = users.id
		ORDER BY 		
			log.dt DESC
		LIMIT
			$start, 50 #$$conf{portion}
EOS
	
	return {
		log => $log,
		cnt => $cnt,
		portion => 50
	};

}

1;