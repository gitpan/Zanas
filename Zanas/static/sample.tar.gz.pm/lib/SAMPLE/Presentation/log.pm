################################################################################

sub draw_log {
	
	my ($data) = @_;
	
	return
	
		draw_hr (height => 10)
		
		.
	
		draw_window_title ({
			label => '��������'
		})
	
		.
		
		draw_toolbar (
			{},
			draw_toolbar_pager ({
				cnt    => 0 + @{$data -> {log}},
				total  => $data -> {cnt},
				portion => $data -> {portion}
			})
		)
		
		.

		draw_table (
			
			['����', '������������', '��������', '���', '������'],
		
			sub { 
				draw_text_cell ({
					label => $i -> {dt}
				})
				.
				draw_text_cell ({
					label => $i -> {label}
				})
				.
				draw_text_cell ({
					label => $i -> {action}
				})
				.
				draw_text_cell ({
					label => $i -> {type}
				})
				.
				draw_text_cell ({
					label => $i -> {error}
				})
			}, 
			$data -> {log}
		)
		
}


1;