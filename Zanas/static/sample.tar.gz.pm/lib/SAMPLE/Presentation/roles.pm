################################################################################

sub draw_roles {
	
	my ($data) = @_;
	
	return
	
		draw_hr (height => 10)
		
		.
	
		draw_window_title ({
			label => '����'
		})
	
		.
		
		draw_toolbar (
			{},
			draw_toolbar_button ({
				icon => 'create',
				label => '&��������',
				href => '?type=roles&action=create',
			}),
		)
		
		.

		draw_table (
		
			sub { 
			
				draw_row_buttons ({},
					[
						{icon => 'edit', label => '�������������', href => "/?type=roles&id=$$i{id}"},
					]
				)
				
				.
			
				draw_text_cell ({
					label => $i -> {label},
					href  => "/?type=roles&id=$$i{id}",
				})
				
				.
			
				draw_text_cell ({
					label => $i -> {name},
					href  => "/?type=roles&id=$$i{id}",
				})

				.
							
				draw_row_buttons ({},
					[
						{icon => 'delete', label => '�������', href => "/?type=roles&action=delete&id=$$i{id}", confirm => "������� ���� $$i{name}?"},
					]
				)
								
			}, 
			
			$data -> {roles}
			
		);
	
}

################################################################################

sub draw_item_of_roles {

	my ($data) = @_;

	draw_form ({}, $data, 
		[
			{
				name  => 'name',
				label => '������������� ���',
			},
			{
				name  => 'label',
				label => '��������',
			},
		]
	);
	
}

1;
